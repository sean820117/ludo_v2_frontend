export default {
    subject: "工程",
    course_name: "工程學群",
    sub_course: [
        {
            id:1,
            title:"簡短的精準自介(共同必修)",
            title2 : "開頭7秒讓教授留下印象！",
            link:"https://player.vimeo.com/video/319273700",
            assistant_id:"03db9c50-f211-11e8-93e5-7514b94dfe78",
            placeholder:"假設你今天是一個"+ "工程學群" +"的申請生，請輸入一段簡短的自我介紹，目的是讓教授快速的認識你。(例如：我是林佳瑾，是一個關注心理健康的人，由於看見上百種不同的衝突都是源自於溝通不良，因此我期待能投入心理領域，在未來帶領大家從人心解決問題)",
        },
        {
            id:2,
            title:"有效的簡歷撰寫(共同必修)",
            title2 : "將平凡經歷寫得有說服力",
            link:"https://player.vimeo.com/video/319273700",
            assistant_id:"03db9c50-f211-11e8-93e5-7514b94dfe78",
            placeholder:"假設你今天是一個"+'工程學群'+"的申請生，請輸入你的經歷，以及嘗試簡短具體的介紹這段經歷。 (例如：我曾擔任班長，在開學短短7天內讓全班35人完成了420項老師的代辦工作)"
        },
        {
            id:3,
            title:"有感的申請動機(共同必修)",
            title2 : "第一步：確認申請動機大綱",
            link:"https://player.vimeo.com/video/319273928"
        },
        {
            id:4,
            title:"有感的申請動機(各科不同)",
            title2 : "第二步：將動機與家庭背景連結",
            link:""
        },
        {
            id:5,
            title:"有感的申請動機(各科不同)",
            title2 : "第三步：有效寫入各科系關鍵字詞",
            link:"",
            assistant_id:"0bd383a0-01cf-11e9-a7e9-21bf6b6391c0",
            placeholder:"假設你今天是一個"+'工程學群'+"的申請生，以下請寫上你完整的申請動機內容。",
        },
        {
            id:6,
            title:"有效的自傳寫法(共同必修)",
            title2 : "第一步：分析與確定多種自傳大綱",
            link:"https://player.vimeo.com/video/319273069"
        },
        {
            id:7,
            title:"有效的自傳寫法(各科不同)",
            title2 : "第二步：如何加入學科的知識性描述",
            link:""
        },
        {
            id:8,
            title:"有效的自傳寫法(各科不同)",
            title2 : "第三步：撰寫人際、溝通、競賽、社團環節",
            link:"",
            assistant_id:"04d9d550-ffad-11e8-a151-cfe41479ab3b",
            placeholder:"假設你今天是一個"+'工程學群'+"的申請生，以下請寫上你完整的自傳內容。",
        },
        {
            id:9,
            title:"不唬人的讀書計畫(共同必修)",
            title2 : "第一步：選擇對的架構(短中長or五大類)",
            link:"https://player.vimeo.com/video/319273231"
        },
        {
            id:10,
            title:"不唬人的讀書計畫(各科不同)",
            title2 : "第二步：寫好專業、語言、職場、研究所等內容",
            link:""
        },
        {
            id:11,
            title:"不唬人的讀書計畫(各科不同)",
            title2 : "第三步：寫好人際關係、自我成長、休閒等內容",
            link:"",
            assistant_id:"03d0ed70-01f5-11e9-a7e9-21bf6b6391c0",
            placeholder:"假設你今天是一個"+'工程學群'+"的申請生，以下請寫上你完整的讀書計畫內容。",
        },
        {
            id:12,
            title:"最後重點強調(共同必修)",
            title2 : "回頭串聯起所有種點",
            link:"https://player.vimeo.com/video/319273548"
        },
    ],
    examples:[
        {  
            sub_course:"經歷",
            rank:"B",
            content:"高中時曾三度參與北醫工程營，並於每年寒暑假擔任台大醫院志工，從中更堅定了自己未來的志向，除了想習得專業知識技能外，也期許自己能成為一位宅心仁厚的助人者。"
        }
    ],
}